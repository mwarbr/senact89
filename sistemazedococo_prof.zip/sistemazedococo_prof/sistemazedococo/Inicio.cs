﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemazedococo
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();

            // removendo a cor de fundo dos paineis
            topo.BackColor = Color.FromArgb(0, 10, 10, 10);
            conteudos.BackColor = Color.FromArgb(0, 10, 10, 10);
            logo.BackColor = Color.FromArgb(0, 10, 10, 10);
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            texto.Text = "Abre uma nova janela para as configurações";
        }

        private void btnPerfil_Click(object sender, EventArgs e)
        {
            texto.Text = "Abre a tela de perfil dentro do painel conteúdos.";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            texto.Text = "Encerra a sessão de login e carrega a tela login";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            texto.Text = "Fecha a aplicação.";
        }
    }
}
